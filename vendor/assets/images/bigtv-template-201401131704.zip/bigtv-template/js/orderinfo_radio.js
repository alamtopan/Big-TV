var CC_NUMBER;
var formCC_TYPE = null;
var formExpMonth = null;
var formExpYear = null;
var submited=0;
function doSubmit(){
        if( submited==0) {
                submited=1;
//                document.form1.submit();

        }
}

function check_email(e) {
	ok = "1234567890qwertyuiop[]asdfghjklzxcvbnm.@-_QWERTYUIOPASDFGHJKLZXCVBNM";

	for(i=0; i < e.length ;i++){
		if(ok.indexOf(e.charAt(i))<0){ 
			return (false);
		}	
	} 

	if (document.images) {
		re = /(@.*@)|(\.\.)|(^\.)|(^@)|(@$)|(\.$)|(@\.)/;
		re_two = /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
		if (!e.match(re) && e.match(re_two)) {
			return (-1);		
		} 

	}

}

function changetxt(teks,tampil){
                document.getElementById("cvvpin").innerHTML = teks;
				if(tampil==0){
					document.getElementById("where_cvv").style.visibility = "hidden";
				} else {
					document.getElementById("where_cvv").style.visibility = "visible";
				}
            }

function get_radio_value()  {

	var brandId = "";
	for (var i=0; i < document.Order_Info.BRANDID.length; i++)     {
   		if (document.Order_Info.BRANDID[i].checked)     	{
      			brandId = document.Order_Info.BRANDID[i].value;
      		}
   	}

	return brandId;
}

     
function Order_Info_Validation(Order_Info)	 {

	if(document.Order_Info.CVV2.value.length < 3) {
		alert("The CVV number should be 3 digits");
		document.Order_Info.CVV2.focus();
		return false;
	}
		 
	if(document.Order_Info.CVV2.value.length==3) {
		document.Order_Info.CVV2.value=document.Order_Info.CVV2.value+"1";
	}

 	if (document.Order_Info.BRANDID.selectedIndex ==" 0" || document.Order_Info.BRANDID.selectedIndex =="-1") {
		alert("Please select a card type.");
		document.Order_Info.BRANDID.focus();
		return false;
 	}
	
	<!--  Credit Card Field  -->
 
  	var cn1 = document.Order_Info.CardNumber.value;
		
	if (cn1=="" || cn1==null) {
		alert("Please enter a valid credit card number.");
		document.Order_Info.CardNumber.focus();
		return false;
	}
	   
	   
	if (cn1 != "") {
		flag = false;
		for (var i=0;i<cn1.length;i++)	{
			if(cn1.charAt(i)>=0 && cn1.charAt(i)<=9) {
				flag = true;
			} else	{
				flag = false;  
			}
		}
	       
		if(!flag) {
			alert("Please enter a valid credit card number.");
			document.Order_Info.CardNumber.focus();
			return false;
		}
	}

	CC_NUMBER=cn1;
	formCC_TYPE = get_radio_value(); //document.Order_Info.BRANDID.[selectedIndex].value;
	//alert(formCC_TYPE);

	if (!CheckCC(CC_NUMBER,formCC_TYPE)) {
		document.Order_Info.CardNumber.focus();
		return false;
	}  
		
	<!--  Expiration Date month -->
	if (document.Order_Info.MONTH.selectedIndex == 0 || document.Order_Info.MONTH.selectedIndex =="-1")	 {
		alert("Please select a month for valid expiry date for your credit card.");
		document.Order_Info.MONTH.focus();
		return false;
	}
		
	<!-- Expiration Year -->
	if (document.Order_Info.YEAR.selectedIndex == 0 || document.Order_Info.YEAR.selectedIndex =="-1") {
		alert("Please select a year for valid expiry date for your credit card.");
		document.Order_Info.YEAR.focus();
		return false;
	}
	
	var now = new Date();
	var m = now.getMonth()+1;						
	var thisMonth = (m < 10) ? '0' + m : m;			
	var yy = now.getYear();					     
 	var thisYear = (yy < 50) ? yy + 2000 : yy;
	
	formExpYear = (formExpYear<50)?formExpYear + 2000 : formExpYear;
		
	if (formExpYear < thisYear)	 {
		alert("Please enter a valid expiry date.");
		return false;
	}
		
	if (formExpYear == thisYear && formExpMonth < thisMonth) {
		alert("Please enter a valid expiry date.");
		return false;
	}
		
	if (formExpYear == thisYear && formExpMonth > thisMonth) {
		alert("Please enter a valid expiry date.");
		return false;
	}
    
	if(document.Order_Info.NAME.value=="" || document.Order_Info.NAME.value==null) {
		alert("Please enter your name on the card.");
		document.Order_Info.NAME.focus();
		return false;
	}
	
	if(document.Order_Info.EMAIL.value=="" || document.Order_Info.EMAIL.value==null) {
		alert("Please enter your valid email address.");
		document.Order_Info.EMAIL.focus();
		return false;
	}

	if(!check_email(document.Order_Info.EMAIL.value)) {
                alert("Please enter your valid email address.");
                document.Order_Info.EMAIL.focus();
                return false;
        }
	
	if(document.Order_Info.CITY.value=="" || document.Order_Info.CITY.value==null) {
		alert("Please enter your city address.");
		document.Order_Info.CITY.focus();
		return false;
	}

	if(document.Order_Info.STATE.value=="" || document.Order_Info.STATE.value==null) {
		alert("Please enter your state address.");
		document.Order_Info.STATE.focus();
		return false;
	}

	if(document.Order_Info.COUNTRY.value=="" || document.Order_Info.COUNTRY.value==null) {
		alert("Please select your country address.");
		document.Order_Info.COUNTRY.focus();
		return false;
	}
	
	if(document.Order_Info.PHONE.value=="" || document.Order_Info.PHONE.value==null || document.Order_Info.PHONE.value.length<5) {
		alert("Please enter your phone.");
		document.Order_Info.PHONE.focus();
		return false;
	}
	
	if(document.Order_Info.ZIP_CODE.value=="" || document.Order_Info.ZIP_CODE.value==null || document.Order_Info.ZIP_CODE.value.length>7) {
		alert("Please enter your postal code of billing address.");
		document.Order_Info.ZIP_CODE.focus();
		return false;
	}
	
	alert("Please Click OK To Proceed\nKlik OK untuk lanjut");
	return true;
}
	
	<!--    Function CC -->
function CheckCC(CC_NUMBER,formCC_TYPE) {
	var CCN_digits = "";
        
	for (var i=0;i<CC_NUMBER.length;i++) {
		
		if ((CC_NUMBER.charAt(i) >="0") && (CC_NUMBER.charAt(i) <="9")) { 
			CCN_digits = CCN_digits + CC_NUMBER.charAt(i);
		}
	}
		
	var validcard = false;
	var msgind = 0;

	if (formCC_TYPE == "Visa/Master"||formCC_TYPE == "3"||formCC_TYPE == "14"||formCC_TYPE == "11" ||formCC_TYPE == "4" || formCC_TYPE=="VISA"  || formCC_TYPE=="MASTERCARD") {

//		formCC_TYPE = "Visa/Master";
		if ( (CCN_digits.length == 16) || (CCN_digits.length ==13) ) {
			
			if ( ((CCN_digits.substring (0, 2) >= "51") && (CCN_digits.substring (0, 2) <= "55")) || (CCN_digits.substring (0, 1) == "4") ) {
                validcard = true;
			} else {
				msgind = 1;
			}
        } else	{	
			msgind = 2;  
		}

	} else if (formCC_TYPE == "BNICARD") {
		 
		formCC_TYPE == "BNI Card";
		if (CCN_digits.length == 16) {
			
			if(CCN_digits.substring (0, 4) == "1946") {
				validcard = true;
			} else {
				msgind = 1;
			}
		} else	{	
			msgind = 2;  
		}
		
	} else if (formCC_TYPE == "DinersClub") {
		 
		formCC_TYPE == "DinersClub";
		if (CCN_digits.length == 14) {
			
			if((CCN_digits.substring (0, 2) == "36")	||  (CCN_digits.substring (0, 2) == "38") ) {
				validcard = true;
			} else {
				msgind = 1;
			}
		} else	{	
			msgind = 2;  
		}

	} else if (formCC_TYPE == "Amex") {
		
		formCC_TYPE = "Amex";
		if (CCN_digits.length == 15) {
			
			if((CCN_digits.substring (0, 2) == "34")	||	(CCN_digits.substring (0, 2) == "37") ) {
				validcard = true;
			} else {
				msgind = 1;
            }
		} else	{	
			msgind = 2;  
		}
		
	} else if (formCC_TYPE == "Master") {
		
		formCC_TYPE= "Master";
		if (CCN_digits.length == 16) {
			if ((CCN_digits.substring (0, 1) == "5")) {
				validcard = true;
			} else {
				msgind = 1;
			}
		} else	{
			msgind = 2;
        }
	
	} else if (formCC_TYPE == "JCB") {
		
		formCC_TYPE = "JCB";
		if (CCN_digits.length == 16) {
			if (CCN_digits.substring (0, 1) == "3") {
				validcard = true;
			} else {
				msgind = 1;
			}
		} else {	
			msgind = 2;
        }

	} else if (formCC_TYPE == "JCB") {
		formCC_TYPE = "JCB";
		if (CCN_digits.length == 15) {
			if (CCN_digits.substring (0, 4) == "2131" || CCN_digits.substring (0, 4) == "1800") {
				validcard = true;
			} else {
				msgind = 1;
			}
		} else	{
			msgind = 2;
        }
	
	} else if (formCC_TYPE == "Visa") {
		formCC_TYPE ="Visa";
		if ((CCN_digits.length == 16)  || (CCN_digits.length ==13)) {
			if (CCN_digits.substring (0, 1) == "4") {
				validcard = true;
			} else	{ 	
				msgind = 1;   
			}
		} else	{	
			msgind = 2; 
		}

	} else {
        alert ("Sorry, kindly ensure your credit card number is correctly entered as shown on your card.");
        return false;
	}

	if (!validcard)	 {
		if (msgind == 1) {
			alert ("The Card Number ("+CC_NUMBER + ") and the Card Type (" + formCC_TYPE + ") do not match.");
			return false;
		} else if (msgind == 2) {
			alert ("The Card Number ("+CC_NUMBER + ") Invalid for  Card Type (" + formCC_TYPE + ").");
			return false;
		}
	}
		
	if (!validcard) {
		return (validcard);
	}


	var CheckSum = 0;
// for loop
	for (var x = 1; x <= CCN_digits.length; x++)	{
		var CurrentDigit = CCN_digits.charAt(CCN_digits.length - x);
		if (x % 2 == 0)				{
			var WorkDigit = CurrentDigit * 2;	
			if (WorkDigit > 9)		{ 
				CheckSum = CheckSum + (1 - 0);
				CheckSum = CheckSum + (WorkDigit % 10 - 0);
			}
			else	{
				CheckSum = CheckSum + (WorkDigit - 0);
			}	
		}
		else	{
			CheckSum = CheckSum + (CurrentDigit - 0);
		}
	} // end of for loop
		
	if (CheckSum % 10) 		{ 
		validcard = false; 
		alert ("The Card Number ("+ CC_NUMBER +") is not correct "); 
		return false;
	} 
	
	return (validcard); 
}
