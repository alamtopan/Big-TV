var CC_NUMBER;
var formCC_TYPE = null;
var formExpMonth = null;
var formExpYear = null;
var submited=0;
function doSubmit(){
    if( submited==0) {
        submited=1;
    //                document.form1.submit();

    }
}

function check_email(e) {
    ok = "1234567890qwertyuiop[]asdfghjklzxcvbnm.@-_QWERTYUIOPASDFGHJKLZXCVBNM";

    for(i=0; i < e.length ;i++){
        if(ok.indexOf(e.charAt(i))<0){
            return (false);
        }
    }

    if (document.images) {
        re = /(@.*@)|(\.\.)|(^\.)|(^@)|(@$)|(\.$)|(@\.)/;
        re_two = /^.+\@(\[?)[a-zA-Z0-9\-\.]+\.([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        if (!e.match(re) && e.match(re_two)) {
            return (-1);
        }

    }

}

var dokuid_reg = /^[0-9]{10}/;

var emai_reg = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i;

function CheckDokuId(form_dokupay){
    //--- we have 2 option (email/dokuId) ---//
    var field = document.form_dokupay.DOKUPAYID.value;

    if (field=="" || field==null) {
        alert("Please enter your DOKU ID.");
        document.form_dokupay.DOKUPAYID.focus();
        return false;
    }

    console.log('check account value '+field);
    if (emai_reg.test(field) == false && dokuid_reg.test(field) == false) {
        console.log('return false on check '+field);
        alert("Please enter a valid DOKU ID ");
        return false;
    } else {
        console.log('return false on check '+field);
        return true;
    }
}

function BNIDebitOnline_Validation(formBNIDebitOnline)       {

    if(document.formBNIDebitOnline.CVV2.value.length < 3) {
        alert("The CVC2 number should be 3 digits");
        document.formBNIDebitOnline.CVV2.focus();
        return false;
    }

    if(document.formBNIDebitOnline.CVV2.value.length==3) {
        document.formBNIDebitOnline.CVV2.value=document.formBNIDebitOnline.CVV2.value+"1";
    }
    <!--  Credit Card Field  -->

    var cn1 = document.formBNIDebitOnline.CARDNUMBER.value;

    if (cn1=="" || cn1==null) {
        alert("Please enter a valid credit card number.");
        document.formBNIDebitOnline.CARDNUMBER.focus();
        return false;
    }


    if (cn1 != "") {
        flag = false;
        for (var i=0;i<cn1.length;i++)  {
            if(cn1.charAt(i)>=0 && cn1.charAt(i)<=9) {
                flag = true;
            } else  {
                flag = false;
            }
        }

        if(!flag) {
            alert("Please enter a valid credit card number.");
            document.formBNIDebitOnline.CARDNUMBER.focus();
            return false;
        }
    }

    CC_NUMBER=cn1;
    //formCC_TYPE = get_radio_value(); //document.formBNIDebitOnline.BRANDID.[selectedIndex].value;
    //alert(formCC_TYPE);

    if (!CheckCC(CC_NUMBER)) {
        document.formBNIDebitOnline.CARDNUMBER.focus();
        return false;
    }

    <!--  Expiration Date month -->
    if (document.formBNIDebitOnline.MONTH.selectedIndex == 0 || document.formBNIDebitOnline.MONTH.selectedIndex =="-1")  {
        alert("Please select a month for valid expiry date for your credit card.");
        document.formBNIDebitOnline.MONTH.focus();
        return false;
    }

    <!-- Expiration Year -->
    if (document.formBNIDebitOnline.YEAR.selectedIndex == 0 || document.formBNIDebitOnline.YEAR.selectedIndex =="-1") {
        alert("Please select a year for valid expiry date for your credit card.");
        document.formBNIDebitOnline.YEAR.focus();
        return false;
    }

    var now = new Date();
    var m = now.getMonth()+1;
    var thisMonth = (m < 10) ? '0' + m : m;
    var yy = now.getYear();
    var thisYear = (yy < 50) ? yy + 2000 : yy;

    formExpYear = (formExpYear<50)?formExpYear + 2000 : formExpYear;

    if (formExpYear < thisYear)      {
        alert("Please enter a valid expiry date.");
        return false;
    }

    if (formExpYear == thisYear && formExpMonth < thisMonth) {
        alert("Please enter a valid expiry date.");
        return false;
    }

    if (formExpYear == thisYear && formExpMonth > thisMonth) {
        alert("Please enter a valid expiry date.");
        return false;
    }

    return true;
}

function Order_Info_Validation(Order_Info)       {

    if(document.Order_Info.CVV2.value.length < 3) {
        alert("The CVV number should be 3 digits");
        document.Order_Info.CVV2.focus();
        return false;
    }

    if(document.Order_Info.CVV2.value.length==3) {
        document.Order_Info.CVV2.value=document.Order_Info.CVV2.value+"1";
    }
    <!--  Credit Card Field  -->

    var cn1 = document.Order_Info.CARDNUMBER.value;

    if (cn1=="" || cn1==null) {
        alert("Please enter a valid credit card number.");
        document.Order_Info.CARDNUMBER.focus();
        return false;
    }


    if (cn1 != "") {
        flag = false;
        for (var i=0;i<cn1.length;i++)  {
            if(cn1.charAt(i)>=0 && cn1.charAt(i)<=9) {
                flag = true;
            } else  {
                flag = false;
            }
        }

        if(!flag) {
            alert("Please enter a valid credit card number.");
            document.Order_Info.CARDNUMBER.focus();
            return false;
        }
    }

    CC_NUMBER=cn1;
    //formCC_TYPE = get_radio_value(); //document.Order_Info.BRANDID.[selectedIndex].value;
    //alert(formCC_TYPE);

    if (!CheckCC(CC_NUMBER)) {
        document.Order_Info.CARDNUMBER.focus();
        return false;
    }

    <!--  Expiration Date month -->
    if (document.Order_Info.MONTH.selectedIndex == 0 || document.Order_Info.MONTH.selectedIndex =="-1")  {
        alert("Please select a month for valid expiry date for your credit card.");
        document.Order_Info.MONTH.focus();
        return false;
    }

    <!-- Expiration Year -->
    if (document.Order_Info.YEAR.selectedIndex == 0 || document.Order_Info.YEAR.selectedIndex =="-1") {
        alert("Please select a year for valid expiry date for your credit card.");
        document.Order_Info.YEAR.focus();
        return false;
    }

    var now = new Date();
    var m = now.getMonth()+1;
    var thisMonth = (m < 10) ? '0' + m : m;
    var yy = now.getYear();
    var thisYear = (yy < 50) ? yy + 2000 : yy;

    formExpYear = (formExpYear<50)?formExpYear + 2000 : formExpYear;

    if (formExpYear < thisYear)      {
        alert("Please enter a valid expiry date.");
        return false;
    }

    if (formExpYear == thisYear && formExpMonth < thisMonth) {
        alert("Please enter a valid expiry date.");
        return false;
    }

    if (formExpYear == thisYear && formExpMonth > thisMonth) {
        alert("Please enter a valid expiry date.");
        return false;
    }

    if(document.Order_Info.NAME.value=="" || document.Order_Info.NAME.value==null) {
        alert("Please enter your name on the card.");
        document.Order_Info.NAME.focus();
        return false;
    }

    if(document.Order_Info.ADDRESS.value=="" || document.Order_Info.ADDRESS.value==null) {
        alert("Please enter your billing address.");
        document.Order_Info.ADDRESS.focus();
        return false;
    }

    <!--  Birth Date Field  -->
    if(document.Order_Info.BDATE.value=="" || document.Order_Info.BDATE.value==null || document.Order_Info.BDATE.value.length > 2) {
        alert("Please enter your birth date.");
        document.Order_Info.BDATE.focus();
        return false;
    }

    if(document.Order_Info.BMONTH.value=="" || document.Order_Info.BMONTH.value==null || document.Order_Info.BMONTH.value.length > 2) {
        alert("Please enter your birth month.");
        document.Order_Info.BMONTH.focus();
        return false;
    }

    if(document.Order_Info.BYEAR.value=="" || document.Order_Info.BYEAR.value==null || document.Order_Info.BYEAR.value.length > 4 || document.Order_Info.BYEAR.value.length < 4) {
        alert("Please enter your birth year.");
        document.Order_Info.BYEAR.focus();
        return false;
    }

    if(document.Order_Info.BDATE.value.length==1) {
        document.Order_Info.BDATE.value="0"+document.Order_Info.BDATE.value;
    }

    if(document.Order_Info.BMONTH.value.length==1) {
        document.Order_Info.BMONTH.value="0"+document.Order_Info.BMONTH.value;
    }

    var bd1 = ""+document.Order_Info.BDATE.value+document.Order_Info.BMONTH.value+document.Order_Info.BYEAR.value;

    if (bd1 != "") {
        flag = false;
        for (var i=0;i<bd1.length;i++)  {
            if(bd1.charAt(i)>=0 && bd1.charAt(i)<=9) {
                flag = true;
            } else  {
                flag = false;
            }
        }

        if(!flag) {
            alert("Please enter a valid birth date.");
            document.Order_Info.BDATE.focus();
            return false;
        }
    }

    <!--  Birth Date Field END -->

    if(document.Order_Info.EMAIL.value=="" || document.Order_Info.EMAIL.value==null) {
        alert("Please enter your valid email address.");
        document.Order_Info.EMAIL.focus();
        return false;
    }

    if(!check_email(document.Order_Info.EMAIL.value)) {
        alert("Please enter your valid email address.");
        document.Order_Info.EMAIL.focus();
        return false;
    }

    if(document.Order_Info.CITY.value=="" || document.Order_Info.CITY.value==null) {
        alert("Please enter your city address.");
        document.Order_Info.CITY.focus();
        return false;
    }

    if(document.Order_Info.STATE.value=="" || document.Order_Info.STATE.value==null) {
        alert("Please enter your state address.");
        document.Order_Info.STATE.focus();
        return false;
    }

    if(document.Order_Info.COUNTRY.value=="" || document.Order_Info.COUNTRY.value==null) {
        alert("Please select your country address.");
        document.Order_Info.COUNTRY.focus();
        return false;
    }

    if(document.Order_Info.PHONE.value=="" || document.Order_Info.PHONE.value==null || document.Order_Info.PHONE.value.length<5) {
        alert("Please enter your phone.");
        document.Order_Info.PHONE.focus();
        return false;
    }

    if(document.Order_Info.ZIP_CODE.value=="" || document.Order_Info.ZIP_CODE.value==null || document.Order_Info.ZIP_CODE.value.length>7) {
        alert("Please enter your postal code of billing address.");
        document.Order_Info.ZIP_CODE.focus();
        return false;
    }

    //alert("Please Click OK To Proceed\nKlik OK untuk lanjut");
    return true;
}

<!-- Function CC -->
function CheckCC(CC_NUMBER) {
    var CCN_digits = "";

    for (var i=0;i<CC_NUMBER.length;i++) {

        if ((CC_NUMBER.charAt(i) >="0") && (CC_NUMBER.charAt(i) <="9")) {
            CCN_digits = CCN_digits + CC_NUMBER.charAt(i);
        }
    }

    var validcard = false;
    var msgind = 0;

    if ( (CCN_digits.length == 16) || (CCN_digits.length ==13) ) {

        if ( (CCN_digits.substring (0, 1) == "5") || (CCN_digits.substring (0, 1) == "4") ) {
            validcard = true;
        } else {
            msgind = 1;
        }

    } else  {
        msgind = 2;
    }

    if (!validcard)  {
        if (msgind == 1) {
            /*alert ("The Card Number ("+CC_NUMBER + ") and the Card Type (" + formCC_TYPE + ") do not match.");*/
            alert ("The Card Number ("+CC_NUMBER + ") and the Card Type (VISA/MASTERCARD) do not match.");
            return false;
        } else if (msgind == 2) {
            /*alert ("The Card Number ("+CC_NUMBER + ") Invalid for Card Type (" + formCC_TYPE + ").");*/
            alert ("The Card Number ("+CC_NUMBER + ") Invalid for Card Type (VISA/MASTERCARD).");
            return false;
        }
    }

    if (!validcard) {
        return (validcard);
    }


    var CheckSum = 0;
    // for loop
    for (var x = 1; x <= CCN_digits.length; x++)    {
        var CurrentDigit = CCN_digits.charAt(CCN_digits.length - x);
        if (x % 2 == 0)                         {
            var WorkDigit = CurrentDigit * 2;
            if (WorkDigit > 9)              {
                CheckSum = CheckSum + (1 - 0);
                CheckSum = CheckSum + (WorkDigit % 10 - 0);
            }
            else    {
                CheckSum = CheckSum + (WorkDigit - 0);
            }
        }
        else    {
            CheckSum = CheckSum + (CurrentDigit - 0);
        }
    }
    // end of for loop

    if (CheckSum % 10)              {
        validcard = false;
        alert ("The Card Number ("+ CC_NUMBER +") is not correct ");
        return false;
    }

    return (validcard);
}